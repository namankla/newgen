<html>
<head><title>Student Details store</title></head>
<body bgcolor= blue>
<form action="store.php" method ="POST">
   <p>Student Name:<input type ="text" name= "name"></p>
   <p>Student ID:<input type ="number" name= "id"></p>
   <p>Department:<input type ="text" name= "dept"></p>
   <p>Student year:<input type ="number" name= "year"></p>
   <p>Address:<br><textarea rows="10" cols="40" name="address"></textarea></p>
   <input type="submit" value="Store">
</form>
</body>
</html>
